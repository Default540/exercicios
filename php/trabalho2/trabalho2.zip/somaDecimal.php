<?php

$n = 3;

$s = 0;

for ($i=1; $i <= $n; $i++) { 
    $s += 1/$i;
}

echo $s;